#include<stdio.h>
int main()
{
 int a[10][10],b[10][10],c[10][10];
 int m,n,p,q;
 int i,j,k;
 printf("enter the order of matrix a:\n");
 scanf("%d%d",&m,&n);
 printf("enter the order of the matrix b:\n");
 scanf("%d%d",&p,&q);
 if(n!=p)
 {
  printf("number of coloumns of matrix A is not equal number rows of  matrix b");
  printf("mutiplication of the matrix is not possible\n");
  return 1;
 }
 printf("enter the elments of matrix A \n");
 for(i=0;i<m;i++)
 {
  for(j=0;j<n;j++)
    {
    scanf("%d",&a[i][j]);
    }
  } 
  printf("matrix A \n");
  for(i=0;i<m;i++)
   {
   for(j=0;j<n;j++)
    {
    printf("%d\t",a[i][j]);
    }
    printf("\n");
   }
  printf("enter the elements of matrix B \n");
  for(i=0;i<p;i++)
  {
   for(j=0;j<q;j++)
    {
     scanf("%d",&b[i][j]);
     }
   }
 printf(" matrix B \n");
  for(i=0;i<p;i++)
  {
   for(j=0;j<q;j++)
    {
     printf("%d\t",b[i][j]);
     }
    printf("\n");
   }
  for(i=0;i<m;i++)
  {
   for(j=0;j<q;j++)
   {
    c[i][j]=0;
    for(k=0;k<n;k++)
    {
     c[i][j]=c[i][j]+a[i][k]*b[k][j];
     }
    }
  }
  printf("the product of matrix \n");
  for(i=0;i<m;i++)
  {
   for(j=0;j<q;j++)
   {
    printf("%d\t",c[i][j]);
    }
   printf("\n");  
   }
 return 0;
}
