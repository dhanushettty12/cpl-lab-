
#include<math.h>
int main()
{
 float *p,a[10],sum,mean,var,sd;
 int i,n;
 printf("enter the number of elements\n");
 scanf("%d",&n);
 printf("enter the elments\n");
 p=a;
 for(i=0;i<n;i++)
 {
  scanf("%f",&*p);
  p++;
 }
 p=a;
 sum=var=sd=mean=0;
 for(i=0;i<n;i++)
 {
  sum=sum+*p;
  p++;
 }
 mean=sum/n;
 p=a;
 for(i=0;i<n;i++)
 {
  var=var+pow((*p-mean),2);
  p++;
 }
 var=var/n;
 sd=sqrt(var);
 printf("mean=%f\nsum=%f\nvar=%f\nsd=%f\n",mean,sum,var,sd);
 return 0;
}

 
